package com.example.data.license

import com.example.data.preferences.UserPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Resultado de consultar el Servidor de Licencias de PedritoTech
 * (POST https://pedritotech.cu/wp-json/ptls/v1/app-validate).
 */
sealed interface LicenseCheckResult {
  /** Licencia activa. expiresAtMs = 0 significa «de por vida». */
  data class Valid(val expiresAtMs: Long) : LicenseCheckResult

  /** El servidor respondió y la licencia no es válida (code: invalid, expired, revoked…). */
  data class Invalid(val code: String, val expiresAtMs: Long = 0L) : LicenseCheckResult

  /** Sin conexión o respuesta ilegible: no se decide nada. */
  data object NetworkError : LicenseCheckResult
}

/**
 * Reglas de uso local de la licencia, compartidas por la puerta de
 * entrada (MainActivity) y el LicenseViewModel.
 */
object LicenseRules {
  const val STATUS_ACTIVE = "active"

  /** Sin conexión, una licencia ya validada sigue usable 7 días. */
  const val GRACE_MS = 7L * 24 * 60 * 60 * 1000

  /** Pasadas 24 h desde la última validación, se vuelve a consultar. */
  const val REVALIDATE_AFTER_MS = 24L * 60 * 60 * 1000

  fun isUsable(prefs: UserPreferences, nowMs: Long): Boolean {
    if (prefs.licenseStatus != STATUS_ACTIVE) return false
    if (prefs.licenseLastValidatedAt <= 0L) return false
    // Vencida por fecha: ni la gracia la salva.
    if (prefs.licenseExpiresAt > 0L && prefs.licenseExpiresAt <= nowMs) return false
    return nowMs - prefs.licenseLastValidatedAt <= GRACE_MS
  }

  fun needsRevalidation(prefs: UserPreferences, nowMs: Long): Boolean {
    if (prefs.licenseDeviceId.isBlank() || prefs.licensePhone.isBlank()) return false
    if (prefs.licenseLastValidatedAt <= 0L) return false
    return nowMs - prefs.licenseLastValidatedAt > REVALIDATE_AFTER_MS
  }
}

object LicenseValidator {
  private const val ENDPOINT = "https://pedritotech.cu/wp-json/ptls/v1/app-validate"

  suspend fun validate(deviceId: String, phone: String): LicenseCheckResult =
    withContext(Dispatchers.IO) {
      try {
        val connection = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
          requestMethod = "POST"
          connectTimeout = 12_000
          readTimeout = 12_000
          doOutput = true
          setRequestProperty("Content-Type", "application/json; charset=utf-8")
          setRequestProperty("Accept", "application/json")
        }
        val payload = JSONObject()
          .put("device_id", deviceId)
          .put("phone", phone)
          .put("product", "stockplus")
          .toString()
        connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
        val httpCode = connection.responseCode
        val body = (if (httpCode in 200..299) connection.inputStream else connection.errorStream)
          ?.bufferedReader()?.use { it.readText() }.orEmpty()
        connection.disconnect()
        if (body.isBlank()) return@withContext LicenseCheckResult.NetworkError
        val json = JSONObject(body)
        val expiresAtMs = json.optLong("expira_ts", 0L) * 1000L
        if (json.optString("status") == "active") {
          LicenseCheckResult.Valid(expiresAtMs)
        } else {
          LicenseCheckResult.Invalid(
            code = json.optString("code").ifBlank { "invalid" },
            expiresAtMs = expiresAtMs,
          )
        }
      } catch (e: Exception) {
        LicenseCheckResult.NetworkError
      }
    }
}
