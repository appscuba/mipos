package com.example.ui.license

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.license.LicenseCheckResult
import com.example.data.license.LicenseRules
import com.example.data.license.LicenseValidator
import com.example.data.preferences.AppPreferencesDataStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LicenseUiState(
  val deviceId: String = "",
  val phone: String = "",
  val status: String = "",
  val expiresAt: Long = 0L,
  val isChecking: Boolean = false,
  val message: String? = null,
  val isError: Boolean = false,
)

class LicenseViewModel(
  private val preferences: AppPreferencesDataStore,
) : ViewModel() {

  private data class Draft(
    val phoneInput: String? = null,
    val isChecking: Boolean = false,
    val message: String? = null,
    val isError: Boolean = false,
  )

  private val draft = MutableStateFlow(Draft())

  val uiState: StateFlow<LicenseUiState> =
    combine(preferences.preferencesFlow, draft) { prefs, d ->
      LicenseUiState(
        deviceId = prefs.licenseDeviceId,
        phone = d.phoneInput ?: prefs.licensePhone,
        status = prefs.licenseStatus,
        expiresAt = prefs.licenseExpiresAt,
        isChecking = d.isChecking,
        message = d.message,
        isError = d.isError,
      )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LicenseUiState())

  init {
    viewModelScope.launch {
      preferences.ensureLicenseDeviceId()
      // La marca del primer arranque enciende la prueba de 15 días.
      preferences.ensureFirstLaunchAt()
    }
  }

  fun onPhoneChange(value: String) {
    draft.update { it.copy(phoneInput = value, message = null) }
  }

  /**
   * Consulta el servidor con el ID de esta instalación y el teléfono
   * escrito. Si la licencia es válida, el plan pasa a LICENSED solo
   * (toda la app deriva el plan de las preferencias guardadas).
   */
  fun activate() {
    val state = uiState.value
    val phone = state.phone.trim()
    if (state.deviceId.isBlank() || phone.isBlank()) {
      draft.update { it.copy(message = "Escribe tu número de teléfono.", isError = true) }
      return
    }
    if (state.isChecking) return
    draft.update { it.copy(isChecking = true, message = null) }
    viewModelScope.launch {
      when (val result = LicenseValidator.validate(state.deviceId, phone)) {
        is LicenseCheckResult.Valid -> {
          preferences.saveLicenseValidation(
            phone = phone,
            status = LicenseRules.STATUS_ACTIVE,
            expiresAt = result.expiresAtMs,
            validatedAt = System.currentTimeMillis(),
          )
          draft.update {
            it.copy(
              isChecking = false,
              message = "Licencia activada. ¡Bienvenido a Stock+!",
              isError = false,
            )
          }
        }
        is LicenseCheckResult.Invalid -> {
          preferences.saveLicenseValidation(
            phone = phone,
            status = result.code,
            expiresAt = result.expiresAtMs,
            validatedAt = 0L,
          )
          draft.update {
            it.copy(
              isChecking = false,
              message = messageForCode(result.code),
              isError = true,
            )
          }
        }
        LicenseCheckResult.NetworkError -> {
          draft.update {
            it.copy(
              isChecking = false,
              message = "Sin conexión con el servidor de licencias. Revisa tu internet e inténtalo de nuevo.",
              isError = true,
            )
          }
        }
      }
    }
  }

  /**
   * Al abrir la app: si la última validación tiene más de 24 h, se
   * reconsulta en silencio. Sin conexión no pasa nada: manda la gracia
   * de 7 días de LicenseRules.
   */
  fun refreshIfStale() {
    viewModelScope.launch {
      val prefs = preferences.preferencesFlow.first()
      val now = System.currentTimeMillis()
      if (!LicenseRules.needsRevalidation(prefs, now)) return@launch
      when (val result = LicenseValidator.validate(prefs.licenseDeviceId, prefs.licensePhone)) {
        is LicenseCheckResult.Valid -> preferences.saveLicenseValidation(
          phone = prefs.licensePhone,
          status = LicenseRules.STATUS_ACTIVE,
          expiresAt = result.expiresAtMs,
          validatedAt = now,
        )
        is LicenseCheckResult.Invalid -> preferences.saveLicenseValidation(
          phone = prefs.licensePhone,
          status = result.code,
          expiresAt = result.expiresAtMs,
          validatedAt = 0L,
        )
        LicenseCheckResult.NetworkError -> Unit
      }
    }
  }

  private fun messageForCode(code: String): String = when (code) {
    "expired" -> "Tu licencia venció. Contacta a PedritoTech para renovarla."
    "revoked" -> "Esta licencia fue revocada. Contacta a PedritoTech."
    else -> "No hay una licencia activa para este ID y teléfono. Verifica el teléfono, o pide tu licencia a PedritoTech por WhatsApp."
  }

  class Factory(
    private val preferences: AppPreferencesDataStore,
  ) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T =
      LicenseViewModel(preferences) as T
  }
}
